
import streamlit as st
import pandas as pd
from components.fetch_flightaware import get_arrivals
from components.process_flight_data import merge_arrivals_with_holding
from components.connection_features import engineer_features
from components.predict_connections import predict_connection_risks
from components.dashboard_tile import render_risk_table

st.set_page_config(layout="wide")
st.title("✈ Heathrow Live Connection Risk – Virgin Atlantic & SkyTeam")

holding_data = pd.DataFrame({
    "flight": ["VS6", "AF1680", "KL1001"],
    "holding": [True, False, True]
})

holding_data["dep_flight"] = ["VS117", "DL32", "VS7"]
holding_data["airline"] = ["VS", "AF", "KL"]
holding_data["dep_time"] = pd.to_datetime(["2025-07-09 14:00:00", "2025-07-09 13:30:00", "2025-07-09 13:50:00"])
holding_data["dep_terminal"] = ["T3", "T3", "T3"]

st.markdown("Fetching simulated FlightAware arrivals...")
arrivals = [
    {
        "ident": "VS6",
        "actual_runway_time": {"epoch": 1752076500},
        "scheduled_in": {"epoch": 1752075600},
        "arrival_terminal": "T3",
        "arrival_gate": "22"
    },
    {
        "ident": "AF1680",
        "actual_runway_time": {"epoch": 1752075000},
        "scheduled_in": {"epoch": 1752074700},
        "arrival_terminal": "T4",
        "arrival_gate": "7"
    },
    {
        "ident": "KL1001",
        "actual_runway_time": {"epoch": 1752075900},
        "scheduled_in": {"epoch": 1752075000},
        "arrival_terminal": "T4",
        "arrival_gate": "5"
    }
]

df = merge_arrivals_with_holding(arrivals, holding_data)
df = engineer_features(df)
df = predict_connection_risks(df)
render_risk_table(df)
