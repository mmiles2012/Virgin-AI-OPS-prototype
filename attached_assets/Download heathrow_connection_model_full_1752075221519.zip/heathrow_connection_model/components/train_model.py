
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import pickle

def train_model(csv_path="data/connection_training.csv", model_path="models/connection_model.pkl"):
    df = pd.read_csv(csv_path)
    features = ["holding_time", "arrival_delay", "connection_buffer", "same_terminal", "alliance_match"]
    X = df[features]
    y = df["missed_connection"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X_train, y_train)

    with open(model_path, "wb") as f:
        pickle.dump(clf, f)

    return clf.score(X_test, y_test)
