
import pandas as pd

def engineer_features(df):
    df["arrival_delay"] = (df["actual_arrival"] - df["scheduled_arrival"]).dt.total_seconds() / 60
    df["connection_buffer"] = (df["dep_time"] - df["actual_arrival"]).dt.total_seconds() / 60
    df["same_terminal"] = (df["terminal"] == df["dep_terminal"]).astype(int)
    df["alliance_match"] = df["airline"].isin(["VS", "DL", "AF", "KL"]).astype(int)
    df["missed_connection"] = (df["connection_buffer"] < 45).astype(int)
    return df
