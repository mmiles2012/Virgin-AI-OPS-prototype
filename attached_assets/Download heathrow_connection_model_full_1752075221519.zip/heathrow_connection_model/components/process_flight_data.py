
import pandas as pd
from datetime import datetime

def merge_arrivals_with_holding(arrivals, holding_df):
    data = []
    for flight in arrivals:
        ident = flight.get("ident")
        arrival_time = flight.get("actual_runway_time", {}).get("epoch")
        scheduled_time = flight.get("scheduled_in", {}).get("epoch")
        terminal = flight.get("arrival_terminal")
        gate = flight.get("arrival_gate")

        data.append({
            "flight": ident,
            "actual_arrival": datetime.utcfromtimestamp(arrival_time) if arrival_time else None,
            "scheduled_arrival": datetime.utcfromtimestamp(scheduled_time) if scheduled_time else None,
            "terminal": terminal,
            "gate": gate
        })

    arrivals_df = pd.DataFrame(data)
    combined_df = pd.merge(holding_df, arrivals_df, on="flight", how="left")
    combined_df["holding_time"] = combined_df["holding"].apply(lambda x: 10 if x else 0)
    return combined_df
