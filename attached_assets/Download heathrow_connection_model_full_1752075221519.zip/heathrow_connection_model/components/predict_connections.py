
import pandas as pd
import pickle

def predict_connection_risks(df, model_path="models/connection_model.pkl"):
    with open(model_path, "rb") as f:
        model = pickle.load(f)

    features = ["holding_time", "arrival_delay", "connection_buffer", "same_terminal", "alliance_match"]
    df["missed_risk"] = model.predict(df[features])
    return df
