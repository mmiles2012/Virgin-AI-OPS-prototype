
import streamlit as st
import pandas as pd

def render_risk_table(df):
    st.subheader("🔗 Connection Risk Table")
    risky = df[df["missed_risk"] == 1]
    st.dataframe(risky[["flight", "dep_flight", "connection_buffer", "holding_time", "terminal", "dep_terminal"]])
