
import requests

def get_arrivals(airport="EGLL", max_results=20, api_key="YOUR_API_KEY"):
    headers = {"Authorization": f"Bearer {api_key}"}
    url = f"https://aeroapi.flightaware.com/aeroapi/airports/{airport}/flights/arrivals?howMany={max_results}"
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json().get("arrivals", [])
    else:
        print(f"API Error: {response.status_code}")
        return []
