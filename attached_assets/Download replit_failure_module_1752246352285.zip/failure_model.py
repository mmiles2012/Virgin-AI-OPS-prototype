
import json
import os

# Load all failure profiles
FAILURE_PROFILE_DIR = os.path.dirname(__file__)

def load_failure_profile(aircraft_type):
    filename = f"{aircraft_type.replace('-', '_')}_failures.json"
    filepath = os.path.join(FAILURE_PROFILE_DIR, filename)
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Failure profile not found for {aircraft_type}")
    with open(filepath, "r") as f:
        return json.load(f)

# Example aircraft object for simulation
class AircraftTwin:
    def __init__(self, aircraft_type, cruise_altitude=37000, fuel_burn=1.0):
        self.aircraft_type = aircraft_type
        self.cruise_altitude = cruise_altitude
        self.fuel_burn = fuel_burn
        self.failure_state = None
        self.systems_lost = []
        self.diverted = False
        self.landing_distance_factor = 1.0

    def apply_failure(self, failure_type):
        profile = load_failure_profile(self.aircraft_type)
        if failure_type not in profile:
            raise ValueError(f"Failure type {failure_type} not defined for {self.aircraft_type}")
        f = profile[failure_type]
        if failure_type == "engine_failure":
            self.cruise_altitude = f["drift_down_altitude_ft"]
            self.fuel_burn *= f["fuel_penalty_factor"]
            self.systems_lost = f["systems_lost"]
            self.diverted = f["diversion_required"]
        elif failure_type == "decompression":
            self.cruise_altitude = f["descent_altitude_ft"]
            self.fuel_burn *= f["fuel_penalty_factor"]
            self.oxygen_duration = f["oxygen_duration_min"]
        elif failure_type == "hydraulic_failure":
            self.systems_lost = f["lost_systems"]
            self.landing_distance_factor = f["landing_distance_factor"]
        self.failure_state = failure_type

    def export_for_ml(self):
        return {
            "aircraft_type": self.aircraft_type,
            "cruise_altitude": self.cruise_altitude,
            "fuel_burn": self.fuel_burn,
            "systems_lost": self.systems_lost,
            "diverted": self.diverted,
            "landing_distance_factor": self.landing_distance_factor,
            "failure_type": self.failure_state
        }

if __name__ == "__main__":
    twin = AircraftTwin("A330-300")
    twin.apply_failure("engine_failure")
    print(twin.export_for_ml())
